hours = 2

seconds = hours * 3600

print(f"{hours} hour(s) is {seconds} seconds.")
