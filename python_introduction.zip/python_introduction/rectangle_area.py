length = 10
width = 5

area = length * width

print(f"The area of the rectangle is: {area}")
