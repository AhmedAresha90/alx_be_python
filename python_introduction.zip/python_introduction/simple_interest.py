# Variables
principal = 1000
rate = 0.05
time = 3

# Calculate simple interest
interest = principal * rate * time

# Print result
print(f"The simple interest is: {interest}.")
