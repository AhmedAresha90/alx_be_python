<<<<<<< HEAD
number1 = 10
number2 = 5

# Calculations1
sum_result = number1 + number2
difference_result = number1 - number2
product_result = number1 * number2

# Printing results1
print(f"Addition of {number1} and {number2} is {sum_result}")
print(f"Subtraction of {number1} and {number2} is {difference_result}")
print(f"Multiplication of {number1} and {number2} is {product_result}")
=======
if __name__ == "__main__":
    number1 = 10
    number2 = 5

    sum_result = number1 + number2
    difference_result = number1 - number2
    product_result = number1 * number2

    print(f"Addition of {number1} and {number2} is {sum_result}")
    print(f"Subtraction of {number1} and {number2} is {difference_result}")
    print(f"Multiplication of {number1} and {number2} is {product_result}")
>>>>>>> 206fbf40de1a25b7bd550e63eea278da98604d20
